# Docker CE Role for Ansible

This is a simple role to install **docker_ce** *(Community version)* from the official repository.

---

&uarr; [Back to top](#)